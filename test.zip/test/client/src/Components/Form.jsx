import React, { useState } from 'react';
import axios from 'axios';
import Input from './Input';
import FileInput from './FileInput';

const Form = () => {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        dob: '',
        residentialAddress: {
            street1: '',
            street2: ''
        },
        sameAsResidential: false,
        permanentAddress: {
            street1: '',
            street2: ''
        },
        documents: [{ fileName: '', fileType: '', file: null }]
    });

    const [errors, setErrors] = useState({});
    const [loading, setLoading] = useState(false);

    // General input change handler
    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        if (name.includes('Address')) {
            const [addressType, field] = name.split('.');
            setFormData(prevData => ({
                ...prevData,
                [addressType]: {
                    ...prevData[addressType],
                    [field]: value
                }
            }));
        } else {
            setFormData(prevData => ({
                ...prevData,
                [name]: type === 'checkbox' ? checked : value
            }));
        }
    };

    // Handling file input changes
    const handleFilesChange = (files) => {
        setFormData(prevData => ({
            ...prevData,
            documents: files
        }));
    };

    // Validation function
    const validate = () => {
        const newErrors = {};
        if (!formData.firstName) newErrors.firstName = 'First name is required';
        if (!formData.lastName) newErrors.lastName = 'Last name is required';
        if (!formData.email || !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(formData.email)) {
            newErrors.email = 'Valid email is required';
        }
        if (!formData.dob) newErrors.dob = 'Date of Birth is required';
        else if (new Date().getFullYear() - new Date(formData.dob).getFullYear() < 18) {
            newErrors.dob = 'Minimum age should be 18 years';
        }
        if (!formData.residentialAddress.street1) newErrors.residentialAddress = { street1: 'Street1 is required' };
        if (!formData.residentialAddress.street2) newErrors.residentialAddress = { street2: 'Street2 is required' };
        if (!formData.sameAsResidential) {
            if (!formData.permanentAddress.street1) newErrors.permanentAddress = { street1: 'Street1 is required' };
            if (!formData.permanentAddress.street2) newErrors.permanentAddress = { street2: 'Street2 is required' };
        }
        if (formData.documents.some(doc => !doc.fileName || !doc.fileType || !doc.file)) {
            newErrors.documents = 'All documents must have a file name, type, and file';
        } else {
            const invalidFileTypes = formData.documents.some(doc => !['image', 'pdf'].includes(doc.fileType));
            if (invalidFileTypes) newErrors.documents = 'Document type must be either image or pdf';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    // API call separated for better structure and testability
    const submitForm = async (formPayload) => {
        try {
            const response = await axios.post('http://localhost:9000/api/candidate', formPayload, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            if (response.success) {
                console.log('Form submitted successfully:', response.data);
                alert("Form Submitted");
                resetForm();
            } else {
                console.error('Unexpected response:', response);
            }
        } catch (error) {
            console.error('Server responded with an error:', error);
        } finally {
            setLoading(false); 
        }
    };

    // Form submission handler
    const handleSubmit = (e) => {
        console.log("form data", formData)
        e.preventDefault();
        if (validate()) {
            setLoading(true); 
            submitForm(formData);
        }
    };

    // Reset the form
    const resetForm = () => {
        setFormData({
            firstName: '',
            lastName: '',
            email: '',
            dob: '',
            residentialAddress: {
                street1: '',
                street2: ''
            },
            sameAsResidential: false,
            permanentAddress: {
                street1: '',
                street2: ''
            },
            documents: [{ fileName: '', fileType: '', file: null }]
        });
        setErrors({});
    };

    return (
        <div className="form-container">
            <h2>Candidate Information</h2>
            <form onSubmit={handleSubmit}>
                <div className='flex'>
                    <Input
                        id="firstName"
                        name="firstName"
                        type="text"
                        value={formData.firstName}
                        placeholder="First Name *"
                        onChange={handleChange}
                        error={errors.firstName}
                    />
                    <Input
                        id="lastName"
                        name="lastName"
                        type="text"
                        value={formData.lastName}
                        placeholder="Last Name *"
                        onChange={handleChange}
                        error={errors.lastName}
                    />
                </div>

                <div className='flex'>
                    <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        placeholder="Email *"
                        onChange={handleChange}
                        error={errors.email}
                    />
                    <div style={{ flex: 1 }}>
                        <Input
                            id="dob"
                            name="dob"
                            type="date"
                            value={formData.dob}
                            placeholder="Date of Birth *"
                            onChange={handleChange}
                            error={errors.dob}
                        />
                        {!errors.dob && <p className='info'>(Min. age should be 18 years)</p>}
                    </div>
                </div>

                <p>Residential Address</p>
                <div className='flex'>
                    <Input
                        id="residentialAddress.street1"
                        name="residentialAddress.street1"
                        type="text"
                        value={formData.residentialAddress.street1}
                        placeholder="Street 1 *"
                        onChange={handleChange}
                        error={errors.residentialAddress?.street1}
                    />
                    <Input
                        id="residentialAddress.street2"
                        name="residentialAddress.street2"
                        type="text"
                        value={formData.residentialAddress.street2}
                        placeholder="Street 2 *"
                        onChange={handleChange}
                        error={errors.residentialAddress?.street2}
                    />
                </div>

                <div className='flex'>
                    <div className="form-group">
                        <input
                            name="sameAsResidential"
                            type="checkbox"
                            checked={formData.sameAsResidential}
                            onChange={handleChange}
                        />
                        <label>Same as Residential</label>
                    </div>
                </div>

                <p>Permanent Address</p>
                <div className='flex'>
                    <Input
                        id="permanentAddress.street1"
                        name="permanentAddress.street1"
                        type="text"
                        value={formData.permanentAddress.street1}
                        placeholder="Street 1"
                        onChange={handleChange}
                        disabled={formData.sameAsResidential}
                        error={errors.permanentAddress?.street1}
                    />

                    <Input
                        id="permanentAddress.street2"
                        name="permanentAddress.street2"
                        type="text"
                        value={formData.permanentAddress.street2}
                        placeholder="Street 2"
                        onChange={handleChange}
                        disabled={formData.sameAsResidential}
                        error={errors.permanentAddress?.street2}
                    />
                </div>

                <FileInput files={formData.documents} setFiles={handleFilesChange} />
                {errors.documents && <p className="error">{errors.documents}</p>}

                <button type="submit" disabled={loading}>
                    {loading ? 'Submitting...' : 'Submit'}
                </button>
            </form>
        </div>
    );
};

export default Form;
