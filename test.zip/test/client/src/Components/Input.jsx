import React from 'react';

const Input = ({ id, name, type, value, placeholder, onChange, error, disabled }) => {
    const isRequired = placeholder.includes('*');

    return (
        <div className="form-group">
            <label htmlFor={id}>
                {placeholder.replace('*', " ")}
                {isRequired && <span style={{ color: 'red' }}>*</span>}
            </label>
            <input
                id={id}
                name={name}
                type={type}
                value={value}
                placeholder={placeholder.replace('*', " ")}
                onChange={onChange}
                disabled={disabled}
                className={error ? 'input-error' : ''}
            />
            {error && <p className="error">{error}</p>}
        </div>
    );
};

export default Input;
