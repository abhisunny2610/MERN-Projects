import React from 'react';
import Input from './Input';

const FileInput = ({ files, setFiles }) => {
    const handleAddFile = () => {
        setFiles([...files, { fileName: '', fileType: '', file: null }]);
    };

    const handleRemoveFile = (index) => {
        setFiles(files.filter((_, i) => i !== index));
    };

    const handleChange = (index, e) => {
        const { name, value, type, files: inputFiles } = e.target;
        const updatedFiles = [...files];

        if (type === 'file') {
            const file = inputFiles[0];
            const fileTypePrefix = file.type.split('/')[0];

            if (fileTypePrefix === updatedFiles[index].fileType) {
                updatedFiles[index].file = file;
                updatedFiles[index].error = '';
            } else {
                updatedFiles[index].error = `File type mismatch! Expected a ${updatedFiles[index].fileType} file.`;
            }
        } else {
            updatedFiles[index][name] = value;
            // Clear any error when the fileType is changed manually
            if (name === 'fileType') {
                updatedFiles[index].error = '';
            }
        }

        setFiles(updatedFiles);
    };

    return (
        <div className="file-inputs">
            {files.map((file, index) => (
                <div key={index} className="file-input">

                    <Input
                        id={`fileName-${index}`}
                        name="fileName"
                        type="text"
                        value={file.fileName}
                        placeholder="File Name"
                        onChange={(e) => handleChange(index, e)}
                    />
                    <div className="form-group">
                        <label htmlFor={`fileType-${index}`}>File Type</label>
                        <select
                            id={`fileType-${index}`}
                            name="fileType"
                            value={file.fileType}
                            onChange={(e) => handleChange(index, e)}
                        >
                            <option value="">Select File Type</option>
                            <option value="image">Image</option>
                            <option value="pdf">PDF</option>
                        </select>
                    </div>
                    <input
                        type="file"
                        onChange={(e) => handleChange(index, e)}
                    />
                    {index === 0 && (
                        <button type="button" onClick={handleAddFile} className="add-file-button">
                            +
                        </button>
                    )}
                    {index > 0 && (
                        <button
                            type="button"
                            onClick={() => handleRemoveFile(index)}
                            className="remove-file-button"
                        >
                            Remove
                        </button>
                    )}
                    {file.error && <p className="error">{file.error}</p>}
                </div>
            ))}
        </div>
    );
};

export default FileInput;
