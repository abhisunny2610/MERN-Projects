const { check, validationResult } = require('express-validator');

const validationRules = () => {
    return [
        (req, res, next) => {
            console.log('Request body before validation:', req.body); // Log req.body before validation
            next(); // Call next to continue to the validation checks
        },
        check('firstName').notEmpty().withMessage('First name is required'),
        check('lastName').notEmpty().withMessage('Last name is required'),
        check('email').notEmpty().withMessage('Email is required'),
        check('dob')
            .notEmpty().withMessage('Date of Birth is required')
            .isDate().withMessage('Date of Birth must be a valid date')
            .custom((value) => {
                const dob = new Date(value);
                const age = new Date().getFullYear() - dob.getFullYear();
                if (age < 18) {
                    throw new Error('Minimum age should be 18 years');
                }
                return true;
            }),
        check('residentialAddress.street1').notEmpty().withMessage('Residential Address Street 1 is required'),
        check('residentialAddress.street2').notEmpty().withMessage('Residential Address Street 2 is required'),
        check('sameAsResidential').custom((value, { req }) => {
            if (!value) {
                if (!req.body.permanentAddress.street1) {
                    throw new Error('Permanent Address Street 1 is required');
                }
                if (!req.body.permanentAddress.street2) {
                    throw new Error('Permanent Address Street 2 is required');
                }
            }
            return true;
        }),
        check('documents').custom((value) => {
            if (!value || value.length < 2) {
                throw new Error('At least two documents are required');
            }
            return true;
        }),
        check('documents.*.fileName').notEmpty().withMessage('Document file name is required'),
        check('documents.*.fileType').notEmpty().withMessage('Document type is required')
            .isIn(['image', 'pdf']).withMessage('Document type must be either image or pdf'),
        check('documents.*.file').notEmpty().withMessage('Document file is required'),
    ];
};

const validate = (req, res, next) => {
    const errors = validationResult(req);
    if (errors.isEmpty()) {
        return next();
    }
    return res.status(422).json({ errors: errors.array() });
};

module.exports = {
    validationRules,
    validate,
};
