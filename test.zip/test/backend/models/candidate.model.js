const mongoose = require("mongoose")


// Address Schema
const addressSchema = new mongoose.Schema({
    street1: {
        type: String,
        required: true,
    },
    street2: {
        type: String,
        required: true,
    },
});


// Document Schema
const documentSchema = new mongoose.Schema({
    fileName: {
        type: String,
        required: true,
    },
    fileType: {
        type: String,
        enum: ['image', 'pdf'],
        required: true,
    },
    file: {
        type: String,
        required: true,
    },
});

const candidateSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: true,
        trim: true,
    },
    lastName: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
    },
    dob: {
        type: Date,
        required: true,
    },
    residentialAddress: {
        type: addressSchema,
        required: true,
    },
    permanentAddress: {
        type: addressSchema,
        required: function() {
            return !this.sameAsResidential;
        },
    },
    sameAsResidential: {
        type: Boolean,
        default: false,
    },
    documents: {
        type: [documentSchema],
        validate: {
            validator: function(docs) {
                return docs.length >= 2;
            },
            message: 'At least two documents are required.',
        },
        required: true,
    },
}, {timestamps: true});

const Candidate = mongoose.model('Candidate', candidateSchema);

module.exports = Candidate;
