const express = require('express');
const { validationRules, validate } = require('../middlewares/validatation');
const { createCandidate } = require('../controllers/candidate.controller');
const upload = require('../middlewares/multer');
const router = express.Router();

router.post('/candidate', validationRules(), validate,  upload.array('documents', 10), createCandidate);

module.exports = router;
