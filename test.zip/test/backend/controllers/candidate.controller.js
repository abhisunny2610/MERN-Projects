const Candidate = require("../models/candidate.model");

const createCandidate = async (req, res) => {
    try {

        // all the validations handles through middleware 

        if (req.files) {
            req.body.documents = req.files.map(file => ({
                fileName: file.originalname,
                fileType: file.mimetype,
                file: file.path
            }));
        }

        const candidate = new Candidate(req.body);
        await candidate.save();

        res.status(201).json({ message: 'Candidate information has been successfully submitted.', success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

module.exports = {createCandidate}
